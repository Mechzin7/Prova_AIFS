import java.util.Scanner;

public class Prova_Alan {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int qtdAvaliacoes, qtdAlunos = 0, media=0 ,nota , notas=0, turma;
		String disciplina, nomeAluno, nomeProfessor;
		
		System.out.println("Informe o nome da disciplina: ");
		disciplina = sc.next();
		System.out.println("Qual o nome do professor? ");
		nomeProfessor = sc.next();
		System.out.println("Informe a turma: ");
		turma = sc.nextInt();
		System.out.println("A turma possui quantos alunos? ");
		qtdAlunos = sc.nextInt();
		System.out.println("Quantas avalia��es foram realizadas? ");
		qtdAvaliacoes = sc.nextInt();
		for(int qtdAluno = 1; qtdAlunos >= qtdAlunos; qtdAlunos++) {
		System.out.println("Informe o nome do aluno: ");
		nomeAluno = sc.next();
		for(int i = 1; i <=3; i++) {
			System.out.println("informe a nota da " + i + "� avalia��o: ");
			nota = sc.nextInt();
			notas = nota + notas;
		    media = notas / i;
		}
		System.out.println("A sua m�dia final �: " + media);
		}
		
		
	}
}

